<script src="<?php echo base_url() ?>assets/assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets/js/jquery.easing.min.js"></script>	
	<script src="<?php echo base_url() ?>assets/assets/js/jquery.sticky.js"></script>
	<script src="<?php echo base_url() ?>assets/assets/js/jquery.scrollTo.js"></script>
	<script src="<?php echo base_url() ?>assets/assets/js/stellar.js"></script>
	<script src="<?php echo base_url() ?>assets/assets/js/wow.min.js"></script>
	<script src="<?php echo base_url() ?>assets/assets/js/owl.carousel.min.js"></script>
	<script src="<?php echo base_url() ?>assets/assets/js/nivo-lightbox.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url() ?>assets/assets/js/custom.js"></script>

</body>

</html>